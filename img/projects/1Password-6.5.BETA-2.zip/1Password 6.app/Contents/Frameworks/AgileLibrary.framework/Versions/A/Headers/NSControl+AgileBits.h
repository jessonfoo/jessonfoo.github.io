//
//  NSControl+AgileBits.h
//  OnePasswordOSX
//
//  Created by Roustem Karimov on 6/21/2013.
//  Copyright (c) 2013 AgileBits Inc. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface NSControl (AgileBits)

- (void)ag_drawRoundedTextFieldBackground;

@end
